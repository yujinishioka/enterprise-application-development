package br.com.fiap.enums;

public enum TipoEquipamento {

	CARDIO, MUSCULACAO
}
