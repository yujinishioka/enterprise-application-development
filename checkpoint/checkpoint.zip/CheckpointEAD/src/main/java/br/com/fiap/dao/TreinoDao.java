package br.com.fiap.dao;

import br.com.fiap.entity.Treino;

public interface TreinoDao extends GenericDao<Treino, Long> {

}
