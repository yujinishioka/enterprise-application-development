package br.com.fiap.dao;

import br.com.fiap.entity.Exercicio;

public interface ExercicioDao extends GenericDao<Exercicio, Long> {

}
