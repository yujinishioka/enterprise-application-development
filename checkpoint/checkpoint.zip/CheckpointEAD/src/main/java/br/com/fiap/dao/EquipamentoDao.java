package br.com.fiap.dao;

import br.com.fiap.entity.Equipamento;

public interface EquipamentoDao extends GenericDao<Equipamento, Long> {

}
