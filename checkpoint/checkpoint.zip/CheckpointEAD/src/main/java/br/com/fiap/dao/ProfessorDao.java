package br.com.fiap.dao;

import br.com.fiap.entity.Professor;

public interface ProfessorDao extends GenericDao<Professor, Long> {

}
