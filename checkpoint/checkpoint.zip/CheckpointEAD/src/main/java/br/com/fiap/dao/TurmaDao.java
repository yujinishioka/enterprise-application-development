package br.com.fiap.dao;

import br.com.fiap.entity.Turma;

public interface TurmaDao extends GenericDao<Turma, Long> {

}
